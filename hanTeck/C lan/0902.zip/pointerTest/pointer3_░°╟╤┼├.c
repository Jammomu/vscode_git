#include <stdio.h>

void changeValuePtr(int y ,int m)
{
	//swiching

}

void main()
{
	int year  = 9;
	int month = 2018;

	printf("�Լ� ȣ�� �� >>> year:%d , month:%d\n", year, month);

	changeValuePtr(year,month);

	printf("�Լ� ȣ�� �� >>> year: %d, month: %d\n",year, month);
}